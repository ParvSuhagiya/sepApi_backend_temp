import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MotionConfig } from 'framer-motion';
import { useState, type ReactNode } from 'react';
import { ToastProvider } from '../components/ui/Toast';
import { SearchSessionProvider } from '../features/search/session';
import { LeadsSessionProvider } from '../features/customers/session';
import { ShortlistProvider } from '../features/shortlist/shortlist';
import { ThemeProvider } from './theme';

/** App-wide providers: theme, toasts, server-state cache, mode sessions, shortlist. */
export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Our client retries idempotent POSTs itself; TanStack must not add more.
            retry: false,
            refetchOnWindowFocus: false,
            gcTime: 5 * 60 * 1000,
          },
          mutations: { retry: false },
        },
      }),
  );
  return (
    <ThemeProvider>
      <MotionConfig reducedMotion="user">
        <QueryClientProvider client={client}>
          <ToastProvider>
            <LeadsSessionProvider>
              <SearchSessionProvider>
                <ShortlistProvider>{children}</ShortlistProvider>
              </SearchSessionProvider>
            </LeadsSessionProvider>
          </ToastProvider>
        </QueryClientProvider>
      </MotionConfig>
    </ThemeProvider>
  );
}
