import type { LeadsResponse } from '../../api/schemas';
import { CountUp, Reveal } from '../../components/motion';
import { MarketNotes } from './MarketNotes';

/** Leads summary panel — no radar, clean stats */
export function LeadsInspector({ result }: { result: LeadsResponse | null }) {
  if (!result) {
    return (
      <div className="er-card flex flex-col items-center justify-center gap-3 py-10 text-center">
        <div className="er-icon-wrap er-icon-brand">
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
          </svg>
        </div>
        <p className="er-label">Leads will appear here</p>
        <p className="er-hint">Describe your offer and click Find Leads</p>
      </div>
    );
  }

  const scores = result.leads.map((lead) => lead.match_score);
  const average = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  const withPhone = result.leads.filter((lead) => lead.phone).length;
  const priceUnknown = result.market_notes.some(
    (note) => note.trim().toLowerCase() === 'price not found',
  );

  return (
    <div className="flex flex-col gap-4">
      <Reveal className="er-card">
        <p className="er-section-title mb-4">Scan Results</p>
        <dl className="grid grid-cols-2 gap-3">
          {[
            { label: 'Leads found', value: result.leads.length },
            { label: 'Avg match', value: average },
            { label: 'With phone', value: withPhone },
            { label: 'Credits used', value: result.meta.credits_used },
          ].map((s) => (
            <div key={s.label} className="er-stat-tile">
              <dt className="er-label">{s.label}</dt>
              <dd className="er-stat-value">
                <CountUp value={s.value} format={(n) => `${n}`} />
              </dd>
            </div>
          ))}
        </dl>
      </Reveal>

      <Reveal delay={0.05} className="er-card">
        <p className="er-section-title mb-3">Market benchmark</p>
        <MarketNotes notes={result.market_notes} />
        {priceUnknown && (
          <p className="mt-2 text-xs text-[--er-muted]">
            Competitor pricing wasn't found — confirm prices yourself before quoting.
          </p>
        )}
      </Reveal>
    </div>
  );
}
