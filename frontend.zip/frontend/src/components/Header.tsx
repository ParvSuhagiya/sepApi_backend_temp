import { Bell, Bookmark, LayoutDashboard, Moon, Search, Sun, Users, Zap } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTheme } from '../app/theme';
import { useCustomerAvailability } from '../features/customers/availability';
import { useOptionalShortlist } from '../features/shortlist/shortlist';
import { ShortlistMenu } from '../features/shortlist/ShortlistDrawer';

const NAV = [
  { to: '/app/income',    label: 'Income',    Icon: LayoutDashboard },
  { to: '/app/customers', label: 'B2B Leads', Icon: Users           },
  { to: '/app/shortlist', label: 'Saved',     Icon: Bookmark        },
] as const;

function getActive(pathname: string) {
  if (pathname.includes('/customers')) return '/app/customers';
  if (pathname.includes('/shortlist')) return '/app/shortlist';
  if (pathname.startsWith('/app'))     return '/app/income';
  return '';
}

export function Header() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { resolved, toggle } = useTheme();
  const { available } = useCustomerAvailability();
  const shortlist = useOptionalShortlist();
  const savedCount = shortlist?.count ?? 0;
  const active = getActive(pathname);

  const visibleNav = NAV.filter((n) => available || n.to !== '/app/customers');

  return (
    <header
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 'var(--z-header)',
        background: 'var(--er-raised)',
        borderBottom: '1px solid var(--er-line)',
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: '0 auto',
          padding: '0 24px',
          height: 56,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}
      >
        {/* Logo */}
        <Link
          to="/"
          aria-label="EarnRadar"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            textDecoration: 'none',
            marginRight: 8,
          }}
        >
          <span
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 32,
              height: 32,
              borderRadius: 8,
              background: 'var(--er-accent)',
              color: '#fff',
              fontSize: 13,
              fontWeight: 800,
              letterSpacing: '-0.02em',
              flexShrink: 0,
            }}
          >
            ER
          </span>
          <span
            style={{
              fontSize: 15,
              fontWeight: 700,
              color: 'var(--er-ink)',
              letterSpacing: '-0.02em',
              display: 'none',
            }}
            className="sm:!block"
          >
            EarnRadar
          </span>
        </Link>

        {/* Nav tabs */}
        <nav
          aria-label="Main navigation"
          style={{ display: 'flex', alignItems: 'center', gap: 2 }}
        >
          {visibleNav.map(({ to, label, Icon }) => {
            const isActive = active === to;
            return (
              <button
                key={to}
                type="button"
                onClick={() => navigate(to)}
                aria-current={isActive ? 'page' : undefined}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '6px 12px',
                  borderRadius: 8,
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: 13,
                  fontWeight: isActive ? 600 : 500,
                  color: isActive ? 'var(--er-accent)' : 'var(--er-muted)',
                  background: isActive ? 'var(--er-accent-bg)' : 'transparent',
                  transition: 'all .15s ease',
                  whiteSpace: 'nowrap',
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    (e.currentTarget as HTMLButtonElement).style.background = 'var(--er-surface)';
                    (e.currentTarget as HTMLButtonElement).style.color = 'var(--er-ink)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
                    (e.currentTarget as HTMLButtonElement).style.color = 'var(--er-muted)';
                  }
                }}
              >
                <Icon size={15} aria-hidden="true" />
                <span className="hidden sm:block">{label}</span>
              </button>
            );
          })}
        </nav>

        {/* Spacer */}
        <div style={{ flex: 1 }} />

        {/* Search */}
        <label className="hidden md:flex" style={{ position: 'relative' }}>
          <span className="sr-only">Search</span>
          <Search
            size={13}
            aria-hidden="true"
            style={{
              position: 'absolute',
              left: 10,
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'var(--er-muted)',
              pointerEvents: 'none',
            }}
          />
          <input
            type="search"
            placeholder="Search…"
            className="er-input"
            style={{ paddingLeft: 30, height: 34, width: 160, fontSize: 13 }}
          />
        </label>

        {/* Credits */}
        <span
          className="hidden sm:flex"
          style={{
            alignItems: 'center',
            gap: 4,
            padding: '4px 10px',
            borderRadius: 8,
            border: '1px solid var(--er-line)',
            background: 'var(--er-surface)',
            fontSize: 11,
            fontWeight: 600,
            color: 'var(--er-ink)',
            whiteSpace: 'nowrap',
          }}
        >
          <Zap size={11} color="var(--er-accent)" />
          184/200
        </span>

        {/* Shortlist */}
        <Link
          to="/app/shortlist"
          aria-label={`Saved (${savedCount})`}
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 34,
            height: 34,
            borderRadius: 8,
            border: '1px solid var(--er-line)',
            background: 'var(--er-surface)',
            color: 'var(--er-muted)',
            textDecoration: 'none',
            flexShrink: 0,
          }}
        >
          <Bookmark size={15} />
          {savedCount > 0 && (
            <span
              aria-hidden="true"
              style={{
                position: 'absolute',
                top: -5,
                right: -5,
                minWidth: 16,
                height: 16,
                borderRadius: 99,
                background: 'var(--er-accent)',
                color: '#fff',
                fontSize: 10,
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '0 3px',
              }}
            >
              {savedCount}
            </span>
          )}
        </Link>

        {/* Notifications */}
        <button
          type="button"
          aria-label="Notifications"
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 34,
            height: 34,
            borderRadius: 8,
            border: '1px solid var(--er-line)',
            background: 'var(--er-surface)',
            color: 'var(--er-muted)',
            cursor: 'pointer',
            flexShrink: 0,
          }}
        >
          <Bell size={15} />
          <span
            aria-hidden="true"
            style={{
              position: 'absolute',
              top: 7,
              right: 7,
              width: 7,
              height: 7,
              borderRadius: '50%',
              background: 'var(--er-danger)',
              border: '1.5px solid var(--er-raised)',
            }}
          />
        </button>

        <ShortlistMenu />

        {/* Theme */}
        <button
          type="button"
          onClick={toggle}
          aria-label={resolved === 'dark' ? 'Light mode' : 'Dark mode'}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 34,
            height: 34,
            borderRadius: 8,
            border: '1px solid var(--er-line)',
            background: 'var(--er-surface)',
            color: 'var(--er-muted)',
            cursor: 'pointer',
            flexShrink: 0,
          }}
        >
          {resolved === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
        </button>

        {/* Avatar */}
        <span
          className="hidden lg:flex"
          style={{
            alignItems: 'center',
            gap: 8,
          }}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: '50%',
              background: 'var(--er-accent)',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 12,
              fontWeight: 700,
              flexShrink: 0,
            }}
          >
            P
          </div>
        </span>
      </div>
    </header>
  );
}
