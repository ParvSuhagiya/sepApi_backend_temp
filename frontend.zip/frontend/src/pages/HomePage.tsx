import { motion } from 'framer-motion';
import { RefreshCw, Shield, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../components/ui/Button';
import { CopyButton } from '../components/ui/CopyButton';
import { Seo } from '../components/Seo';
import type { ApiError } from '../api/errors';
import { Inspector } from '../features/search/Inspector';
import { ProfileForm } from '../features/search/ProfileForm';
import { SearchProgress, SearchResultsSkeleton } from '../features/search/SearchProgress';
import { SearchResults } from '../features/search/SearchResults';
import { useSearchSession } from '../features/search/session';

function SearchError({ error, onRetry }: { error: ApiError; onRetry: () => void }) {
  return (
    <div
      role="alert"
      style={{
        padding: '16px 20px',
        borderRadius: 10,
        border: '1px solid rgba(220,38,38,.25)',
        background: 'var(--er-danger-bg)',
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
      }}
    >
      <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--er-ink)', margin: 0 }}>{error.message}</p>
      {error.requestId && (
        <p style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--er-muted)', margin: 0 }}>
          Code:{' '}
          <code
            style={{
              background: 'var(--er-surface)',
              border: '1px solid var(--er-line)',
              borderRadius: 6,
              padding: '2px 8px',
              fontFamily: 'monospace',
            }}
          >
            {error.requestId}
          </code>
          <CopyButton text={error.requestId} label="support code" />
        </p>
      )}
      <Button variant="secondary" onClick={onRetry}>Retry</Button>
    </div>
  );
}

export function HomePage() {
  const session = useSearchSession();
  const loading = session.status === 'loading';
  const [refreshing, setRefreshing] = useState(false);

  function refresh() {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1400);
  }

  return (
    <section aria-labelledby="income-heading" style={{ display: 'flex', flexDirection: 'column', gap: 20, padding: '24px 0' }}>
      <Seo route="/app/income" />

      {/* Page header */}
      <div
        className="er-card"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 12,
        }}
      >
        <div>
          <h1 id="income-heading" style={{ fontSize: 20, fontWeight: 700, color: 'var(--er-ink)', margin: '0 0 4px', letterSpacing: '-0.02em' }}>
            Income Discovery
          </h1>
          <p style={{ fontSize: 13, color: 'var(--er-muted)', margin: 0 }}>
            Find freelance gigs, local gaps, and remote jobs matched to your skills
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              fontSize: 12,
              color: 'var(--er-muted)',
              padding: '5px 10px',
              border: '1px solid var(--er-line)',
              borderRadius: 8,
              background: 'var(--er-surface)',
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                background: 'var(--er-success)',
                display: 'inline-block',
                animation: 'er-pulse 2s ease-in-out infinite',
              }}
            />
            Indore MP-09
          </span>
          <button
            type="button"
            onClick={refresh}
            className="er-btn er-btn-secondary"
            style={{ fontSize: 12, padding: '5px 12px', height: 32 }}
          >
            <RefreshCw size={13} style={{ animation: refreshing ? 'spin 1s linear infinite' : 'none' }} />
            {refreshing ? 'Refreshing…' : 'Refresh'}
          </button>
        </div>
      </div>

      {/* Main layout */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr',
          gap: 20,
          alignItems: 'start',
        }}
        className="xl:!grid-cols-[1fr_300px]"
      >
        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Search form */}
          <div className="er-card">
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 16,
                paddingBottom: 14,
                borderBottom: '1px solid var(--er-line)',
              }}
            >
              <p style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 14, fontWeight: 600, color: 'var(--er-ink)', margin: 0 }}>
                <SlidersHorizontal size={15} color="var(--er-accent)" />
                Search Parameters
              </p>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--er-muted)' }}>
                <Shield size={11} color="var(--er-success)" />
                Anti-Scam Active
              </span>
            </div>
            <ProfileForm loading={loading} onSubmit={session.run} />
          </div>

          {/* Results area */}
          {loading && (
            <>
              <SearchProgress retrying={session.retrying} />
              <SearchResultsSkeleton />
            </>
          )}

          {session.status === 'error' && session.error && (
            <SearchError error={session.error} onRetry={session.retry} />
          )}

          {session.status === 'success' && session.result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <SearchResults />
            </motion.div>
          )}

          {/* Empty state samples */}
          {session.status !== 'success' && session.status !== 'loading' && session.status !== 'error' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ fontSize: 12, color: 'var(--er-muted)', fontWeight: 600 }}>EXAMPLE RESULTS</p>

              {/* Good lead */}
              <div
                className="er-card"
                style={{
                  borderLeft: '3px solid var(--er-accent)',
                  paddingLeft: 16,
                }}
              >
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
                  <span className="er-badge er-badge-brand">94% Fit</span>
                  <span className="er-badge er-badge-green">Escrow Verified</span>
                  <span className="er-badge er-badge-neutral">Indore · Local Gap</span>
                </div>
                <p style={{ fontWeight: 700, fontSize: 15, color: 'var(--er-ink)', margin: '0 0 6px' }}>
                  Cloud Kitchen WhatsApp Automation
                </p>
                <p style={{ fontSize: 13, color: 'var(--er-muted)', margin: '0 0 8px', lineHeight: 1.6 }}>
                  Food collective losing 22% margin to aggregator apps. Deploy WhatsApp catalog + UPI checkout.
                </p>
                <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--er-ink)', margin: 0 }}>
                  ₹28,000 – ₹45,000/mo
                  <span style={{ fontSize: 12, fontWeight: 400, color: 'var(--er-muted)', marginLeft: 6 }}>~12 hrs/week</span>
                </p>
              </div>

              {/* Scam blocked */}
              <div
                className="er-card"
                style={{ borderColor: 'rgba(220,38,38,.2)', background: 'var(--er-danger-bg)' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div className="er-icon-wrap er-icon-red" style={{ width: 36, height: 36 }}>
                    <Shield size={16} />
                  </div>
                  <div>
                    <span className="er-badge er-badge-red" style={{ marginBottom: 4 }}>Fraud Blocked</span>
                    <p style={{ fontWeight: 700, fontSize: 13, color: 'var(--er-danger)', margin: 0 }}>
                      Captcha Typing Scam — ₹999 upfront deposit demanded
                    </p>
                  </div>
                </div>
                <p style={{ fontSize: 13, color: 'var(--er-muted)', marginTop: 10, marginBottom: 0, lineHeight: 1.6 }}>
                  Detected: advance payment heuristic #402. Domain blacklisted. You were protected.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Right sidebar */}
        <div
          style={{ display: 'flex', flexDirection: 'column', gap: 16 }}
          className="xl:sticky xl:top-[76px]"
        >
          <Inspector result={session.result} />
        </div>
      </div>
    </section>
  );
}
